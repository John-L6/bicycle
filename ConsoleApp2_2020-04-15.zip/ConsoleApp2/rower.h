#pragma once

// Mo�emy utworzy� obiekt statyczny lub dynamiczny alokuj�c pami�� i u�ywaj�c wska�nik�w. 
// Generalnie nie ma prawie �adnej r�nicy.
// Tworz�c obiekt statyczny, robimy to tak jak deklaracja zwyk�ej zmiennej :

class rower
{
public:
	double waga;
	int rama;
};

